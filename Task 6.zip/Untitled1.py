#!/usr/bin/env python
# coding: utf-8

# In[ ]:


#Arrays
import numpy

def arrays(arr):
    #revrser array first, convert to float array with numpy
   return(numpy.array(arr[::-1], float))
    # complete this function
    # use numpy.array


# In[ ]:


#Shape&Reshape
import numpy as np
print(np.array(input().split(),int).reshape(3,3))


# In[ ]:


#Transpose&Flatten
import numpy
n, m = map(int, input().split())
array = numpy.array([input().strip().split() for _ in range(n)], int)
print (array.transpose())
print (array.flatten())


# In[ ]:


#Concatenate
import numpy as np
a, b, c = map(int,input().split())
arrA = np.array([input().split() for _ in range(a)],int)
arrB = np.array([input().split() for _ in range(b)],int)
print(np.concatenate((arrA, arrB), axis = 0))


# In[ ]:


#Zeroes&Ones
import numpy
nums = tuple(map(int, input().split()))
print (numpy.zeros(nums, dtype = numpy.int))
print (numpy.ones(nums, dtype = numpy.int))


# In[ ]:


#Eye&Identity
import numpy
print(str(numpy.eye(*map(int,input().split()))).replace('1',' 1').replace('0',' 0'))


# In[ ]:


#ArrayMathematics
import numpy as np
n, m = map(int, input().split())
a, b = (np.array([input().split() for _ in range(n)], dtype=int) for _ in range(2))
print(a+b, a-b, a*b, a//b, a%b, a**b, sep='\n')


# In[ ]:


#Floor,Ceil&Rint
import numpy
numpy.set_printoptions(sign=' ')

a = numpy.array(input().split(),float)

print(numpy.floor(a))
print(numpy.ceil(a))
print(numpy.rint(a))


# In[ ]:


#Sum&Prod
import numpy
N, M = map(int, input().split())
A = numpy.array([input().split() for _ in range(N)],int)
print(numpy.prod(numpy.sum(A, axis=0), axis=0))


# In[ ]:


#Min&Max
import numpy
n,m=map(int,input().split())

lista=[list(map(int,input().split())) for i in range(n)]

ar=numpy.array(lista)

print(max(numpy.min(ar,axis=1)))


# In[ ]:


#Mean,Var&Std
import numpy
N,M = map(int,input().split())
A = numpy.array([input().split() for _ in range(N)], int)
print(A.mean(axis=1))
print(A.var(axis=0))
print(numpy.round(A.std(), decimals=11))


# In[ ]:


#Dot&Cross
import numpy
n=int(input())
a = numpy.array([input().split() for _ in range(n)],int)
b = numpy.array([input().split() for _ in range(n)],int)
m = numpy.dot(a,b)
print (m)


# In[ ]:


#Inner&Outer
import numpy as np
A = np.array(input().split(), int)
B = np.array(input().split(), int)
print(np.inner(A,B), np.outer(A,B), sep='\n')


# In[ ]:


#Polynomials
import numpy
n = list(map(float,input().split()));
m = input();
print(numpy.polyval(n,int(m)));


# In[ ]:


#LinearAlgebra
import numpy
n=int(input())
a=numpy.array([input().split() for _ in range(n)],float)
numpy.set_printoptions(legacy='1.13') #important
print(numpy.linalg.det(a))


# In[ ]:




